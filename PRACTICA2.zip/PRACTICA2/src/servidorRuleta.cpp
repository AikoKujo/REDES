/*
 * servidorRuleta.cpp
 *
 *  Created on: 12 oct. 2021
 *      Author: Jose Manuel Flores Barranco
 				Aitana Delgado Cabanillas
 */

#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <unistd.h>
#include <time.h>
#include <arpa/inet.h>

#include <vector>
#include <queue>

#include "User.h"
#include "Ruleta.h"

#define MSG_SIZE 250
#define MAX_CLIENTS 30

using namespace std;

/*
 * El servidor ofrece el servicio de una ruleta de la suerte
 */

/**
 * Devuelve el indice del vector que coincide con el descriptor pasado como parametro
 * @return -1 si falla
 * 		    n siendo n el indice del vector
 */

int getUserBySD(const int sd, vector <User> &usuarios);

void manejador(int signum);
void salirCliente(int socket, fd_set * readfds, int * numClientes, int arrayClientes[]);

int main ( ) {

	queue <User> ready;
	string aux, aux1; //Para almacenar variables en sscanf()

	/*----------------------------------------------------
		Descriptor del socket y buffer de datos
	-----------------------------------------------------*/
	int sd, new_sd;
	struct sockaddr_in sockname, from;
	char buffer[MSG_SIZE];
	socklen_t from_len;
    fd_set readfds, auxfds;
   	int salida;
   	int arrayClientes[MAX_CLIENTS];
    int numClientes = 0;
	int recibidos;



    int on, ret;

	/*----------------------------------------------------
		USUARIOS
	-----------------------------------------------------*/

	User u, u2;
	vector <User> usuarios;


	/*----------------------------------------------------
		RULETAS
	-----------------------------------------------------*/
	Ruleta r;
	vector <Ruleta> ruletas;

	/* --------------------------------------------------
		Se abre el socket
	---------------------------------------------------*/
  	sd = socket (AF_INET, SOCK_STREAM, 0);
	if (sd == -1)
	{
		perror("No se puede abrir el socket cliente\n");
    		exit (1);
	}

    	// Activaremos una propiedad del socket para permitir· que otros
    	// sockets puedan reutilizar cualquier puerto al que nos enlacemos.
    	// Esto permite· en protocolos como el TCP, poder ejecutar un
    	// mismo programa varias veces seguidas y enlazarlo siempre al
   	 	// mismo puerto. De lo contrario habrÌa que esperar a que el puerto
    	// quedase disponible (TIME_WAIT en el caso de TCP)
    	on=1;
    	ret = setsockopt( sd, SOL_SOCKET, SO_REUSEADDR, &on, sizeof(on));



	sockname.sin_family = AF_INET;
	sockname.sin_port = htons(2050);
	sockname.sin_addr.s_addr =  INADDR_ANY;

	if (bind (sd, (struct sockaddr *) &sockname, sizeof (sockname)) == -1)
	{
		perror("Error en la operación bind");
		exit(1);
	}


   	/*---------------------------------------------------------------------
		De las peticiones que vamos a aceptar sólo necesitamos el
		tamaño de su estructura, el resto de información (familia, puerto,
		ip), nos la proporcionará el método que recibe las peticiones.
   	----------------------------------------------------------------------*/
	from_len = sizeof (from);


	if(listen(sd,1) == -1){
		perror("Error en la operación de listen");
		exit(1);
	}

	//Inicializar los conjuntos fd_set
    	FD_ZERO(&readfds);
    	FD_ZERO(&auxfds);
    	FD_SET(sd,&readfds);
    	FD_SET(0,&readfds);


    	//Capturamos la señal SIGINT (Ctrl+c)
    	signal(SIGINT,manejador);

	/*-----------------------------------------------------------------------
		El servidor acepta una petición
	------------------------------------------------------------------------ */
		while(1){

            //Esperamos recibir mensajes de los clientes (nuevas conexiones o mensajes de los clientes ya conectados)

            auxfds = readfds;

            salida = select(FD_SETSIZE,&auxfds,NULL,NULL,NULL);

            if(salida > 0){


                for(int i=0; i<FD_SETSIZE; i++){

                    //Buscamos el socket por el que se ha establecido la comunicación
                    if(FD_ISSET(i, &auxfds)) {
                    	// ES UN SOCKET NUEVO
                        if( i == sd){
                        	//COMPROBAMOS SI LA LECTURA DEL SOCKET ES VALIDA
                            if((new_sd = accept(sd, (struct sockaddr *)&from, &from_len)) == -1){
                                perror("Error aceptando peticiones");
                            }
                            else
                            {//COMPROBAMOS SI SE PUEDE ACEPTAR LA PETICION DE CONEXION DEL NUEVO CLIENTE
                                if(numClientes < MAX_CLIENTS){
                                    arrayClientes[numClientes] = new_sd;
                                    numClientes++;
                                    FD_SET(new_sd,&readfds);

                                    strcpy(buffer, "Bienvenido a la RULETA DE LA SUERTE\n");
                                    send(new_sd,buffer,sizeof(buffer),0);

                                    bzero(buffer,sizeof(buffer));

                                    strcpy(buffer, "+Ok. Usuario conectado\n");
                                    send(new_sd,buffer,sizeof(buffer),0);

                                    u = User(new_sd);
                                    u.setState(0);
                                    usuarios.push_back(u);

                                    for(int j=0; j<(numClientes-1);j++){

                                        bzero(buffer,sizeof(buffer));
                                        sprintf(buffer, "Nuevo Cliente conectado: %d\n",new_sd);
                                        send(arrayClientes[j],buffer,sizeof(buffer),0);

                                    }
                                }
                                else
                                {
                                    bzero(buffer,sizeof(buffer)); //Limpiar buffer
                                    strcpy(buffer,"Demasiados clientes conectados\n");
                                    send(new_sd,buffer,sizeof(buffer),0);
                                    close(new_sd);
                                }

                            }


                        }
                        else if (i == 0){ //EL SOCKET ES EL PROPIO SERVIDOR
                            //Se ha introducido información de teclado
                            bzero(buffer, sizeof(buffer));
                            fgets(buffer, sizeof(buffer),stdin);

                            //Controlar si se ha introducido "SALIR", cerrando todos los sockets y finalmente saliendo del servidor. (implementar)
                            if(strcmp(buffer,"SALIR\n") == 0){

                                for (int j = 0; j < numClientes; j++){
						  			 bzero(buffer, sizeof(buffer));
						  			strcpy(buffer,"Desconexión servidor\n");
                                    send(arrayClientes[j],buffer , sizeof(buffer),0);
                                    close(arrayClientes[j]);
                                    FD_CLR(arrayClientes[j],&readfds);
                                }
                                    close(sd);
                                    exit(-1);


                            }
                            //Mensajes que se quieran mandar a los clientes (implementar)

                        }
                        else{ // ES UN MENSAJE DE UN CLIENTE
                        	int index = getUserBySD(i, usuarios);
                            bzero(buffer,sizeof(buffer));

                            recibidos = recv(i,buffer,sizeof(buffer),0);

                            if(recibidos > 0){

                                if(strcmp(buffer,"SALIR\n") == 0){

                                    salirCliente(i,&readfds,&numClientes,arrayClientes);

                                }
                                else{

                                	if (usuarios[index].getState() == 0) {

                                		if((sscanf(buffer, "USUARIO %s", aux) == 1) && !usuarios[index].hasUsername()){
                                			//usuarios[index].validateUsername(buffer); SI TRUE
                                			usuarios[index].setUsername(aux);

                                			bzero(buffer,sizeof(buffer));
                                			strcpy(buffer,"+OK. Usuario correcto\n");
                                			send(usuarios[index].getSD(), buffer,sizeof(buffer),0);

                                			//ELSE

                                			 /*
	                                			bzero(buffer,sizeof(buffer));
	                                			strcpy(buffer,"-Err. Ususario incorrecto\n");
	                                			send(usuarios[index].getSD(), buffer,sizeof(buffer),0);
                                			 */
                                		}

                                		else if (usuarios[index].hasUsername() && sscanf(buffer, "PASSWORD %s", aux) == 1) {
                                			//usuarios[index].validatePassword(buffer); SI TRUE
											usuarios[index].setPassword(aux);
											u.setState(1);

											bzero(buffer,sizeof(buffer));
											strcpy(buffer,"+OK. Usuario validado\n");
											send(usuarios[index].getSD(), buffer,sizeof(buffer),0);

											//ELSE

                                			 /*
	                                			bzero(buffer,sizeof(buffer));
	                                			strcpy(buffer,"-Err. Error en la validación \n");
	                                			send(usuarios[index].getSD(), buffer,sizeof(buffer),0);
                                			 */
                                		}

                                		else if ((sscanf(buffer, "REGISTER -u %s -p %s", aux, aux1) == 2) ){

											if(!usuarios[index].hasUsername() && !usuarios[index].hasPassword()){
		                       						usuarios[index].setUsername(aux);
													usuarios[index].setPassword(aux1);
													//usuarios[index].writeUser();

													bzero(buffer,sizeof(buffer));
													strcpy(buffer,"+OK. Usuario registrado\n");
													send(usuarios[index].getSD(), buffer,sizeof(buffer),0);
		                      				}
		                      				else if(usuarios[index].hasUsername()){
                                    			bzero(buffer,sizeof(buffer));
												strcpy(buffer,"-Err. No puede realizar un registro mientras se logea\n");
												send(usuarios[index].getSD(), buffer,sizeof(buffer),0);
                                  			}

		                      				else{

                                    			bzero(buffer,sizeof(buffer));
												strcpy(buffer,"-Err. Credenciales existentes\n");
												send(usuarios[index].getSD(), buffer,sizeof(buffer),0);
                                  			}

                                    	}

                                	}

                                	if (usuarios[index].getState() == 1) {
                                		if(strcmp(buffer,"INICIAR-PARTIDA\n") == 0) {

											if(ready.empty()){
                        						ready.push(usuarios[index]);

                        						bzero(buffer,sizeof(buffer));
                        						strcpy(buffer,"+OK. Emparejando...\n");
                        						send(usuarios[index].getSD(), buffer,sizeof(buffer),0);
                        						usuarios[index].setState(2);
                     						}

											else {
												u2 = ready.front();
												ready.pop();
												r = Ruleta(usuarios[index],u2);
												ruletas.push_back(r);

												u2.setState(3); //El jugador que sale de la cola empieza el turno
												usuarios[index].setState(4); //El otro jugador espera turno

												bzero(buffer,sizeof(buffer));
												sprintf(buffer, "+OK. Rival encontrado: %d\n Iniciando partida...", usuarios[index].getUsername());
												send(u2.getSD(), buffer,sizeof(buffer),0);

												bzero(buffer,sizeof(buffer));
												sprintf(buffer, "+OK. Rival encontrado: %d\n Iniciando partida...", u2.getUsername());
												send(usuarios[index].getSD(), buffer,sizeof(buffer),0);

											}
                                		}
                                	}
                                }
                            }
                            //Si el cliente introdujo ctrl+c
                            if(recibidos== 0)
                            {
                                printf("El socket %d, ha introducido ctrl+c\n", i);
                                //Eliminar ese socket
                                salirCliente(i,&readfds,&numClientes,arrayClientes);
                            }
                        }
                    }
                }
            }
		}
	close(sd);
	return 0;

}

int getUserBySD(const int sd, vector <User> &usuarios) {
	int indice = -1;

	for (size_t i = 0; i<usuarios.size(); i++) {
		if (usuarios[i].getSD() == sd) {
			indice = i;
			return indice;
		}
	}

	return indice;
}

void salirCliente(int socket, fd_set * readfds, int * numClientes, int arrayClientes[]){

    char buffer[250];

    close(socket);
    FD_CLR(socket,readfds);

    //Re-estructurar el array de clientes
    for (int j = 0; j < (*numClientes) - 1; j++)
        if (arrayClientes[j] == socket)
            break;
    for (int j = 0; j < (*numClientes) - 1; j++)
        (arrayClientes[j] = arrayClientes[j+1]);

    (*numClientes)--;

    bzero(buffer,sizeof(buffer));
    sprintf(buffer,"Desconexión del cliente: %d\n",socket);

    for(int j=0; j<(*numClientes); j++)
        if(arrayClientes[j] != socket)
            send(arrayClientes[j],buffer,sizeof(buffer),0);


}

void manejador (int signum){
    printf("\nSe ha recibido la señal sigint\n");
    signal(SIGINT,manejador);

    //Implementar lo que se desee realizar cuando ocurra la excepción de ctrl+c en el servidor
}
