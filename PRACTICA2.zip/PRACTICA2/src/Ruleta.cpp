/*
 * Ruleta.cpp
 *
 *  Created on: 6 oct. 2021
 *      Author: aikokujo,
 *      	Aitana
 */

#include "Ruleta.h"

Ruleta :: Ruleta(User u1, User u2){
  	u1_ = u1;
  	u2_ = u2;
  	//fraseResuelta_ = getFraseAleatoria();
  	//fraseOculta_ = getFraseOculta(fraseResuelta);
;}

Ruleta::Ruleta() { // @suppress("Class members should be properly initialized")
	// TODO Auto-generated constructor stub

}

Ruleta::~Ruleta() {
	// TODO Auto-generated destructor stub
}

Ruleta::Ruleta(const Ruleta &other) { // @suppress("Class members should be properly initialized")
	// TODO Auto-generated constructor stub

}

Ruleta& Ruleta::operator=(const Ruleta &other) { // @suppress("No return")
	// TODO Auto-generated method stub

}


User Ruleta :: UserWTurn(){

    	if(u1_.getState() == 3){

        	return u1_;
      }

      return u2_;
  	}


 /*

 string getFraseAleatoria(){

     int indice;
     string fraseResuelta;

     indice = rand()%20;

     ifstream f;

     f.open(Refranes.txt);

     for(int i=0; i<indice; i++){

       getline(f, fraseResuelta);
     }

     return fraseResuelta;
   }
  */


