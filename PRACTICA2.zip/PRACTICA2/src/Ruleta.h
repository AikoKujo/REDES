/*
 * Ruleta.h
 *
 *  Created on: 6 oct. 2021
 *      Author: aikokujo,
 *      	Aitana
 */

#ifndef SRC_RULETA_H_
#define SRC_RULETA_H_
#include "User.h"


class Ruleta {
private:
	string fraseResulta_;
	string fraseOculta_;
	User u1_, u2_;

public:
	Ruleta();
	Ruleta(User u1_, User u2_);
	virtual ~Ruleta();
	Ruleta(const Ruleta &other);
	Ruleta& operator=(const Ruleta &other);

	User UserWTurn();


};

#endif /* SRC_RULETA_H_ */
